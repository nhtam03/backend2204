package haivi.vn.cochi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CochiApplicationTests {

    @Test
    void contextLoads() {
    }

}
