package haivi.vn.cochi.dto;

import haivi.vn.cochi.entities.ProductCartEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.ArrayList;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrdersDto {
    private Long id;
    private Long userId;
    private String number;
    private Double total;
    private Integer checkout;
    private Integer checkPayment;
    private String addressShip;
    private String day;
    private List<ProductCartEntity> carts=new ArrayList<>();
}
