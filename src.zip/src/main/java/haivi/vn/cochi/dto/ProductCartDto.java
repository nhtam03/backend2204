package haivi.vn.cochi.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProductCartDto {
    private Long Id;
    private Integer number;
    private Long productId;
    private Long userId;
    private Long orderId;
    private Integer status;
}
