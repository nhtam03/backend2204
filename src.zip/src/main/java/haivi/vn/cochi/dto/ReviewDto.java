package haivi.vn.cochi.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReviewDto {
    private Long id;
    private Long userId;
    private Long productId;
    private Integer mark;
    private String content;
    private String date;
    private Integer status;
    private String fullName;
}
