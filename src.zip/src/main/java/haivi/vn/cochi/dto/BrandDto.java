package haivi.vn.cochi.dto;

import haivi.vn.cochi.entities.BrandEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.BeanUtils;

import javax.validation.constraints.NotNull;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BrandDto {
    private Long id;
    @NotNull(message = "Name is not empty")
    private String nameEn;
    @NotNull(message = "Name is not empty")
    private String nameVi;
public BrandEntity converToEntity(){
    BrandEntity brandEntity= new BrandEntity();
    BeanUtils.copyProperties(this,brandEntity);
    return brandEntity;
}
}
