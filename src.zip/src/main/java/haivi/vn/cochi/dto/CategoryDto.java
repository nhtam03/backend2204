package haivi.vn.cochi.dto;

import haivi.vn.cochi.entities.CategoryEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.BeanUtils;

import javax.validation.constraints.NotNull;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CategoryDto {
    private Long id;
    @NotNull(message = "Name is not empty")
    private String nameEn;
    @NotNull(message = "Name is not empty")
    private String nameVi;
    public CategoryEntity convertoEntity(){
        CategoryEntity categoryEntity= new CategoryEntity();
        BeanUtils.copyProperties(this,categoryEntity);
        return categoryEntity;
    }
}
