package haivi.vn.cochi.dto.user;

import haivi.vn.cochi.entities.user.RoleEntity;
import haivi.vn.cochi.entities.user.UserEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.BeanUtils;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserDto {
    private  Long id;
    @NotNull(message = "Full name is not empty")
    private  String fullName;
    @Pattern(regexp = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$",message = "Please enter a valid email")
    private String email;
    private String passWord;
    @NotNull(message = "Phone is not empty")
    private String phone;
    private String address;
    private int status;
    List<RoleEntity> roles = new ArrayList<>();

    public UserEntity convertToEntity(){
        UserEntity userEntity= new UserEntity();
        BeanUtils.copyProperties(this,userEntity);
        return userEntity;
    }
}
