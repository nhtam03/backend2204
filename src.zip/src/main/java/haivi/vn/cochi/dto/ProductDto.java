package haivi.vn.cochi.dto;

import haivi.vn.cochi.entities.ProductEntity;
import haivi.vn.cochi.entities.ReviewEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.BeanUtils;

import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProductDto {

    private Long id;
    private String codeEn;
    private String codeVi;
    private String nameEn;
    private String nameVi;
    private String packing;
    private String elementEn;
    private String elementVi;
    private String userManualEn;
    private String userManualVi;
    private String expiry;
    private String descriptionEn;
    private String descriptionVi;
    private Long categoryId;
    private Long brandId;
    private Double price;
    private Integer status;
    private String image;
    private String image1;
    private String image2;
    private String image3;
    private String image4;
    private List<ReviewEntity> reviews= new ArrayList<>();

    public ProductEntity convertToEntity(){
        ProductEntity productEntity = new ProductEntity();
        BeanUtils.copyProperties(this,productEntity);
        return productEntity;
    }
}
