package haivi.vn.cochi.dto.user;

import haivi.vn.cochi.entities.user.RoleEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.BeanUtils;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RoleDto {
    private Long id;
    private String role;
    private String descriptionVi;
    private String descriptionEn;

    public RoleEntity convertToEntity(){
        RoleEntity roleEntity= new RoleEntity();
        BeanUtils.copyProperties(this,roleEntity);
        return roleEntity;
    }
}
