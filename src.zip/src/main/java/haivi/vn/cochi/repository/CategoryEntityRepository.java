package haivi.vn.cochi.repository;

import haivi.vn.cochi.entities.CategoryEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryEntityRepository extends JpaRepository<CategoryEntity,Long> {
}
