package haivi.vn.cochi.repository;

import haivi.vn.cochi.entities.OrdersEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrdersEntityRepository extends JpaRepository<OrdersEntity,Long> {
}
