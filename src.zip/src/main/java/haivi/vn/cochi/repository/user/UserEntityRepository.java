package haivi.vn.cochi.repository.user;

import haivi.vn.cochi.entities.user.UserEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface UserEntityRepository extends JpaRepository<UserEntity,Long> {
    UserEntity findFirstByEmail(String email);
    boolean existsByEmail(String email);

    @Query(value = "select u from UserEntity u where u.fullName like %?1%")
    Page<UserEntity> findAll(String key, Pageable pageable);
    Page<UserEntity> findAll( Pageable pageable);

    @Query("SELECT u FROM UserEntity u WHERE u.fullName=:username")
    public UserEntity getUserByUsername(@Param("username") String username);

    @Query(value = "SELECT u.FULL_NAME FROM USER u WHERE u.ID= :ID",nativeQuery = true)
    public String findFullName(@Param("ID") Long id);
}
