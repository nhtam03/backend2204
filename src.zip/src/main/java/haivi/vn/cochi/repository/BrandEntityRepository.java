package haivi.vn.cochi.repository;

import haivi.vn.cochi.entities.BrandEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BrandEntityRepository extends JpaRepository<BrandEntity,Long> {
}
