package haivi.vn.cochi.repository;

import haivi.vn.cochi.entities.ProductEntity;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ProductEntityRepository extends JpaRepository<ProductEntity,Long> {

    @Query(value = "Select * from PRODUCT p where p.CODE_EN=:CODE",nativeQuery =true)
    ProductEntity findProductByCodeEn(@Param("CODE") String codeEn);

    @Query(value = "Select p.* from PRODUCT p where p.CATEGORY_ID= :ID LIMIT 4",nativeQuery =true)
    public List<ProductEntity> findAllCategoryId(@Param("ID") Long id);

    @Query(value = "select  product.* from product_cart  \n" +
            "join PRODUCT  on product_cart.PRODUCT_ID=PRODUCT.ID\n" +
            "WHERE product_cart.`STATUS`=1\n" +
            "group by product_cart.PRODUCT_ID\n" +
            "order by   sum(product_cart.NUMBER) desc\n" +
            "LIMIT 6;",nativeQuery =true)
    public List<ProductEntity> findAllTop6Sale();

    @Query(value = "select  product.* from review  \n" +
            "join PRODUCT  on review.PRODUCT_ID=PRODUCT.ID\n" +
            "WHERE review.`STATUS`=1\n" +
            "group by review.PRODUCT_ID\n" +
            "order by   sum(review.MARK) desc\n" +
            "LIMIT 6;",nativeQuery =true)
    public List<ProductEntity> findAllTop6Review();

    @Query(value = "select  product.* from review  \n" +
            "join PRODUCT  on review.PRODUCT_ID=PRODUCT.ID\n" +
            "WHERE review.`STATUS`=1\n" +
            "group by review.PRODUCT_ID\n" +
            "order by   sum(review.MARK) desc;" ,nativeQuery =true)
    public List<ProductEntity> findAllSortReview();



    @Query(value = "SELECT  p.* from PRODUCT p \n" +
            " join PRODUCT_CART c on c.PRODUCT_ID=p.ID \n" +
            " WHERE c.STATUS=1\n" +
            "  group by c.PRODUCT_ID \n" +
            "  order by sum(c.NUMBER) DESC;",nativeQuery = true)
    public List<ProductEntity> findAllSortSale();
}
