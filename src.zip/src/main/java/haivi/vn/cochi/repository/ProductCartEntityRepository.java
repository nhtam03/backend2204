package haivi.vn.cochi.repository;

import haivi.vn.cochi.entities.ProductCartEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ProductCartEntityRepository extends JpaRepository<ProductCartEntity,Long> {

    ProductCartEntity findFirstByProductIdAndUserId(Long productId, Long userId);

    @Query(value = "SELECT c.* FROM PRODUCT_CART c where c.USER_ID= :id and c.STATUS=0",nativeQuery = true)
    List<ProductCartEntity> findAllCart(@Param("id") Long id);

    @Query(value = "SELECT c.* FROM PRODUCT_CART c where c.ORDER_ID= :id",nativeQuery = true)
    List<ProductCartEntity> findAllCartByOrder(@Param("id") Long id);
}
