package haivi.vn.cochi.repository.user;

import haivi.vn.cochi.entities.user.UserRoleEntity;
import org.hibernate.annotations.SQLDeleteAll;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface UserRoleEntityRepository extends JpaRepository<UserRoleEntity,Long> {
        void deleteAllByUserId(Long id);

        @Transactional
        @Modifying
        @Query("DELETE FROM UserRoleEntity u where u.roleId=:roleid")
        public void deleteAllByRoleId(@Param("roleid") Long roleid);

}
