package haivi.vn.cochi.repository;

import haivi.vn.cochi.entities.ReviewEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ReviewEntityRepository extends JpaRepository<ReviewEntity,Long> {
    @Query(value = "SELECT r.* FROM REVIEW r WHERE r.PRODUCT_ID= :ID AND STATUS=1", nativeQuery = true)
    List<ReviewEntity> findAllProductId(@Param("ID") Long id);
}
