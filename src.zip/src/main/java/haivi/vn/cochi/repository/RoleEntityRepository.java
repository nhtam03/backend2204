package haivi.vn.cochi.repository;

import haivi.vn.cochi.entities.user.RoleEntity;
import haivi.vn.cochi.entities.user.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface RoleEntityRepository extends JpaRepository<RoleEntity,Long> {

}
