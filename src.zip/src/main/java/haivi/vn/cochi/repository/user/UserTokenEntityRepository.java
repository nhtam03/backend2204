package haivi.vn.cochi.repository.user;

import haivi.vn.cochi.entities.user.UserTokenEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserTokenEntityRepository extends JpaRepository<UserTokenEntity,Long> {
    UserTokenEntity findFirstByToken(String token);
    public  void deleteAllByUserId(Long id);
}
