package haivi.vn.cochi.controller;

import haivi.vn.cochi.dto.ProductDto;
import haivi.vn.cochi.services.BrandService;
import haivi.vn.cochi.services.CategoryService;
import haivi.vn.cochi.services.ProductService;
import haivi.vn.cochi.utils.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;

@Controller
@PreAuthorize("hasAnyRole('ROLE_ADMIN','CREATER')")// Phân quyền tại đây hoặc trong SecurityConfiguration
@RequestMapping("backend/product")
public class ProductController {
    @Autowired
    CategoryService categoryService;
    @Autowired
    BrandService brandService;
    @Autowired
    ProductService productService;




    //Upload file len thu muc trong may
    @PostMapping("upload")
    @ResponseBody
    public String upload(@RequestParam("file") MultipartFile file) throws Exception {
        return FileUtils.saveFile(file);
    }
    @RequestMapping("list")
    public String list(@RequestParam(defaultValue = "1", required = false) Integer page,
                       @RequestParam(defaultValue = "5", required = false) Integer perpage,
                       @RequestParam(required = false) String seachKey, Model model) {
        productService.List(page, perpage, seachKey, model);
        return "backend/product/product_list";
    }
    @RequestMapping("create")
    public String create(Model model, ProductDto productDto){
        model.addAttribute("productDto",productDto);
        model.addAttribute("categories", categoryService.findAll());
        model.addAttribute("brands", brandService.findAll());
        return "backend/product/product_create";
    }
    @RequestMapping(value = "save",method = RequestMethod.POST,consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public String save(@Valid @ModelAttribute ProductDto productDto,
                       BindingResult bindingResult, RedirectAttributes model){
        if(bindingResult.hasErrors())
            return "backend/product/product_create";
        productService.save(productDto);
        return "redirect:/backend/product/list";
    }

    @RequestMapping("/update/{id}")
    public String update(@PathVariable Long id, Model model){
        ProductDto productDto= productService.detailById(id);
        if(productDto== null)
            return "backend/product/product_update";
        model.addAttribute("productDto", productDto);
        model.addAttribute("brandDto", brandService.findAll());
        model.addAttribute("categoryDto", categoryService.findAll());
        return "backend/product/product_update";
    }


    @RequestMapping(value = "update", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public String update(ProductDto productDto, Model model) {
        productService.save(productDto);
        model.addAttribute("productDto",productDto);
        return "redirect:/backend/product/list";
    }
    @RequestMapping("delete/{id}")
    public String delete (@PathVariable Long id){
        productService.delete(id);
        return "redirect:/backend/product/list";
    }


}
