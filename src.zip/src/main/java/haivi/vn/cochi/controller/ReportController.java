package haivi.vn.cochi.controller;

import haivi.vn.cochi.services.BrandService;
import haivi.vn.cochi.services.CategoryService;
import haivi.vn.cochi.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@PreAuthorize("hasAnyRole('ROLE_ADMIN','CREATER')")// Phân quyền tại đây hoặc trong SecurityConfiguration
@RequestMapping("backend/report")
public class ReportController {
    @Autowired
    CategoryService categoryService;
    @Autowired
    BrandService brandService;
    @Autowired
    ProductService productService;

    @RequestMapping("product/sale")
    public String listsale( Model model) {
        productService.findAllSortSale( model);
        return "backend/report/product_top_sale";
    }
    @RequestMapping("product/review")
    public String listreview( Model model) {
        productService.findAllSortReview( model);
        return "backend/report/product_top_sale";
    }


}
