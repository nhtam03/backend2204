package haivi.vn.cochi.controller;

import haivi.vn.cochi.dto.CategoryDto;
import haivi.vn.cochi.services.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;

@Transactional
@Controller
@PreAuthorize("hasAnyRole('ROLE_ADMIN','CREATER')")// Phân quyền tại đây hoặc trong SecurityConfiguration
@RequestMapping("/backend/category")
public class CategoryController {
    @Autowired
    CategoryService categoryService;

    @RequestMapping("list")
    public String list(Model model, @RequestParam(defaultValue = "1",required = false) Integer page,
                       @RequestParam(defaultValue = "5",required = false) Integer perpage,
                       @RequestParam(required = false) String seachKey){
        categoryService.list(page,perpage,seachKey,model);
        return "backend/category/category_list";
    }
    @RequestMapping("update/{id}")
    public String update(@PathVariable Long id, Model model){
        CategoryDto categoryDto = categoryService.detailById(id);
        model.addAttribute("categoryDto",categoryDto);
        return "backend/category/category_update";
    }
    @RequestMapping(value = "update",method = RequestMethod.POST,consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public String update(@Valid @ModelAttribute CategoryDto categoryDto,
                         BindingResult bindingResult, RedirectAttributes model){
        if(bindingResult.hasErrors())
            return "backend/category/category_list";
        categoryService.update(categoryDto);
        return "redirect:/backend/category/list";
    }
    @RequestMapping("create")
    public String create(CategoryDto categoryDto, Model model){
        model.addAttribute("categoryDto",categoryDto);
        return "backend/category/category_create";
    }
    @RequestMapping(value = "save",method = RequestMethod.POST,consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public String save(@Valid @ModelAttribute CategoryDto categoryDto,
                       BindingResult bindingResult, RedirectAttributes model){
        if(bindingResult.hasErrors())
            return "backend/category/category_create";
        categoryService.save(categoryDto);
        return "redirect:/backend/category/list";
    }
    @RequestMapping("delete/{id}")
    public String delete(@PathVariable Long id, RedirectAttributes model){
        CategoryDto categoryDto= categoryService.detailById(id);
        if(categoryDto!=null)
            categoryService.delete(categoryDto);
        return "redirect:/backend/category/list";
    }
}
