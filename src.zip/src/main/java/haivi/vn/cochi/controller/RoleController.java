package haivi.vn.cochi.controller;

import haivi.vn.cochi.dto.user.RoleDto;
import haivi.vn.cochi.entities.user.RoleEntity;
import haivi.vn.cochi.repository.RoleEntityRepository;
import haivi.vn.cochi.services.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;
import java.util.List;

@Controller
@PreAuthorize("hasAnyRole('ROLE_ADMIN','EDITOR')")// Phân quyền tại đây hoặc trong SecurityConfiguration
@RequestMapping("backend/role")
public class RoleController {

    @Autowired
    RoleService roleService;
    @Autowired
    RoleEntityRepository roleEntityRepository;


    @RequestMapping("list")
    public String list(@RequestParam(defaultValue = "1",required = false) Integer page,
                       @RequestParam(defaultValue = "5",required = false) Integer perpage,
                       @RequestParam(required = false) String seackKey, Model model){
        roleService.list(page,perpage,seackKey,model);
        return "backend/role/role_list";
    }
    @RequestMapping("update/{id}")
    public String update(@PathVariable Long id, Model model){
        RoleDto roleDto= roleService.findById(id);
        model.addAttribute("roleDto",roleDto);
        return "backend/role/role_update";
    }
    @RequestMapping("create")
    public String create(Model model,RoleDto roleDto){
        model.addAttribute("roleDto",roleDto);
        return "backend/role/role_create";
    }
    @RequestMapping(value = "save", method = RequestMethod.POST,consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public String save(@Valid @ModelAttribute RoleDto  roleDto,
                       BindingResult bindingResult, RedirectAttributes model) {
        if (bindingResult.hasErrors())
            return "redirect:/backend/brand/create";
        roleService.save(roleDto);
        model.addFlashAttribute("roleDto", roleDto);
        return "redirect:/backend/role/list";
    }
    @RequestMapping(value = "update", method = RequestMethod.POST,consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public String update(@Valid @ModelAttribute RoleDto  roleDto,
                       BindingResult bindingResult, RedirectAttributes model) {
        if (bindingResult.hasErrors())
            return "redirect:/backend/brand/update";
        roleService.save(roleDto);
        model.addFlashAttribute("roleDto", roleDto);
        return "redirect:/backend/role/list";
    }
    public List<RoleEntity> findAll(){
        return roleEntityRepository.findAll();
    }
    @RequestMapping("delete/{id}")
    public String delete(@PathVariable Long id, RedirectAttributes model){
        RoleEntity roleEntity= roleService.findById(id).convertToEntity();
        if(roleEntity!=null)
            roleService.delete(id);
        return "redirect:/backend/role/list";
    }
}
