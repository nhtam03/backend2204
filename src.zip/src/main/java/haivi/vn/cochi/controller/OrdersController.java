package haivi.vn.cochi.controller;

import haivi.vn.cochi.dto.OrdersDto;
import haivi.vn.cochi.dto.RepositoryDto;
import haivi.vn.cochi.entities.OrdersEntity;
import haivi.vn.cochi.repository.OrdersEntityRepository;
import haivi.vn.cochi.services.OrdersService;
import haivi.vn.cochi.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;

@Controller
@PreAuthorize("hasAnyRole('ROLE_ADMIN','EDITOR')")// Phân quyền tại đây hoặc trong SecurityConfiguration
@RequestMapping("backend/order")

public class OrdersController {
    @Autowired
    OrdersService ordersService;
    @Autowired
    UserService userService;


    @RequestMapping("list")
    public  String list(Model model, @RequestParam(defaultValue = "1",required = false) Integer page,
                        @RequestParam(defaultValue = "5",required = false) Integer perpage,
                        @RequestParam(required = false) String seachKey){
        ordersService.list(page,perpage,seachKey,model);
        return "backend/order/order_list";
    }

    @RequestMapping("update/{id}")
    public String update(Model model,@PathVariable Long id) {
        OrdersDto ordersDto = ordersService.detailById(id);
        model.addAttribute("ordersDto", ordersDto);
        model.addAttribute("user",userService.detailById(ordersDto.getUserId()));
        return "backend/order/order_update";
    }
    @RequestMapping(value = "update",method = RequestMethod.POST,consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public String update(@Valid @ModelAttribute OrdersDto ordersDto,
                         BindingResult bindingResult, RedirectAttributes model) {
        if (bindingResult.hasErrors())
            return "redirect:/backend/order/update";
        ordersService.update(ordersDto);
        return "redirect:/backend/order/list";
    }
    @RequestMapping("delete/{id}")
    public String delete(@PathVariable Long id){
        OrdersDto ordersDto=ordersService.detailById(id);
        if(ordersDto!=null)
            ordersService.delete(ordersDto);
        return "redirect:/backend/order/list";
    }
}
