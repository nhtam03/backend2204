package haivi.vn.cochi.controller;

import haivi.vn.cochi.dto.ReviewDto;
import haivi.vn.cochi.services.ReviewService;
import haivi.vn.cochi.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;

@Controller
@PreAuthorize("hasAnyRole('ROLE_ADMIN','EDITOR')")
@RequestMapping("backend/review")
public class ReviewController {
    @Autowired
    ReviewService reviewService;
    @Autowired
    UserService userService;

    @RequestMapping("list")
    public  String list(Model model, @RequestParam(defaultValue = "1",required = false) Integer page,
                        @RequestParam(defaultValue = "5",required = false) Integer perpage,
                        @RequestParam(required = false) String seachKey){
        reviewService.list(page,perpage,seachKey,model);
        return "backend/review/review_list";
    }

    @RequestMapping(value = "update/{id}")
    public String update(Model model,@PathVariable Long id) {
        ReviewDto reviewDto = reviewService.detailById(id);
        if(reviewDto!=null)
            reviewService.updateReview(reviewDto);
        return "redirect:/backend/review/list";
    }

    @RequestMapping("delete/{id}")
    public String delete(@PathVariable Long id){
        ReviewDto reviewDto=reviewService.detailById(id);
        if(reviewDto!=null)
            reviewService.deleteReview(reviewDto);
        return "redirect:/backend/review/list";
    }
}
