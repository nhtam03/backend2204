package haivi.vn.cochi.controller.user;

import haivi.vn.cochi.dto.user.RoleDto;
import haivi.vn.cochi.dto.user.UserDto;
import haivi.vn.cochi.repository.user.UserEntityRepository;
import haivi.vn.cochi.services.RoleService;
import haivi.vn.cochi.services.UserService;
import org.hibernate.annotations.Parameter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;

@Controller
@PreAuthorize("hasAnyRole('ROLE_ADMIN','EDITOR')")// Phân quyền tại đây hoặc trong SecurityConfiguration
@RequestMapping("/backend/user")
public class UserController {

    @Autowired
    UserService userService;
    @Autowired
    UserEntityRepository userEntityRepository;
    @Autowired
    RoleService roleService;

    @RequestMapping ("list")
    public String list(Model model, @RequestParam(required = false,defaultValue = "1") Integer page,
                       @RequestParam(required = false,defaultValue = "5") Integer perpage,
                       @RequestParam(required = false) String seachKey){
        userService.list(page,perpage,seachKey,model);
        return "backend/user/user_list";
    }
    @RequestMapping("update/{id}")
    public String update(@PathVariable Long id, Model model, UserDto userDto){
        userDto= userService.detailById(id);
        model.addAttribute("roleDto",roleService.findAll());
        model.addAttribute("userDto",userDto);
        return "backend/user/user_update";
    }
    @RequestMapping(value = "update",method = RequestMethod.POST,consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public String update(@ModelAttribute UserDto userDto, RedirectAttributes model){
        userService.save(userDto);
        return "redirect:/backend/user/list";
    }
    @RequestMapping("create")
    public String create(Model model){
        model.addAttribute("userDto", new UserDto());
        model.addAttribute("roleDto",roleService.findAll());
        return "backend/user/user_create";
    }
    @RequestMapping(value = "save",method = RequestMethod.POST,consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public String save(@Valid @ModelAttribute UserDto userDto,
                       BindingResult bindingResult,
                       RedirectAttributes model){
        if(bindingResult.hasErrors())
            return "backend/user/user_create";
        else {
            userService.save(userDto);
            return "redirect:/backend/user/list";
        }

    }
}
