package haivi.vn.cochi.controller;

import haivi.vn.cochi.dto.ProductCartDto;
import haivi.vn.cochi.dto.ProductDto;
import haivi.vn.cochi.dto.RepositoryDto;
import haivi.vn.cochi.dto.ReviewDto;
import haivi.vn.cochi.dto.user.UserDto;
import haivi.vn.cochi.entities.OrdersEntity;
import haivi.vn.cochi.entities.user.UserEntity;
import org.springframework.http.HttpStatus;
import haivi.vn.cochi.services.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;
import java.util.List;

@Controller
public class HomeController {

    @Autowired
    ProductService productService;
    @Autowired
    BrandService brandService;
    @Autowired
    CategoryService categoryService;
    @Autowired
    UserService userService;
    @Autowired
    ReviewService reviewService;


    @RequestMapping({"home","/",""})
    public String home(Model model){
        List<ProductDto> productDtos =productService.findAll();
        model.addAttribute("productDtos",productDtos);
        model.addAttribute("productTop6Sale",productService.findAllTop6Sale());
        model.addAttribute("productTop6Review",productService.findAllTop6Review());
        return "frontend/home";
    }

    @RequestMapping("login")
    public String login(){
        return "login";
    }

    @RequestMapping("signin")
    public String signin(){
        return "signin";
    }

    @RequestMapping(value = "signin", method = RequestMethod.POST, consumes= MediaType.APPLICATION_FORM_URLENCODED_VALUE )
    public String savesignin(@Valid @ModelAttribute UserDto userDto,
                             BindingResult bindingResult,// ngay sau bien co @Valid, chứa kết quả sau khi valid
                             RedirectAttributes model) throws Exception{
        if(bindingResult.hasErrors()){
            return "signin";
        }

        else {
            RepositoryDto repositoryDto=userService.signin(userDto);
            model.addFlashAttribute("message", repositoryDto.getMessage());
            return "redirect:/login";
        }
    }
    @RequestMapping("active-account/{token}")
    public String activeAccount(@PathVariable String token, RedirectAttributes model) {
        model.addFlashAttribute("message", userService.verifyToken(token));
        return "redirect:/login";
    }


    @RequestMapping("product/{codeEn}")
    public String updateCodeEn(@PathVariable String codeEn, Model model){
        ProductDto productDto= productService.detailByCodeEn(codeEn);
        if(productDto== null)
            return "product";
        model.addAttribute("productDto", productDto);
        model.addAttribute("brandDto", brandService.findAll());
        model.addAttribute("categoryDto", categoryService.detailById(productDto.getBrandId()));
        model.addAttribute("productDtos",productService.findAllByCategory(productDto.getCategoryId()));
        model.addAttribute("reviews",reviewService.reviewDtoList(productDto.getId()));

        return "frontend/product_detail";
    }
    @RequestMapping(value = "product/cart", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @ResponseBody
    @ResponseStatus(HttpStatus.OK)
    public RepositoryDto cart(@RequestBody ProductCartDto dto) throws Exception {
        productService.cart(dto);
        return new RepositoryDto(1,"Thêm giỏ hàng thành công");
    }
    @GetMapping("/carts")
    public String checkout(Model model) {
        try {
            Long userId = ((UserEntity) SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getId();
            model.addAttribute("carts", productService.getListCart());
            model.addAttribute("user",userService.detailById(userId));
        }
        catch (Exception e){
            return "/login";
        }
        return "frontend/product_cart";
    }
    @RequestMapping(value = "/cart/checkout", method = RequestMethod.POST, consumes= MediaType.APPLICATION_FORM_URLENCODED_VALUE )
    public String cartCheckout(Model model) {
        OrdersEntity ordersEntity = new OrdersEntity();
        try {
            Long userId = ((UserEntity) SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getId();
            productService.checkout();
        }
        catch (Exception e){
            return "/login";
        }
        return "redirect:/home";
    }
    @RequestMapping("/product/review/save")
    public String productReview(ReviewDto reviewDto, Model model){
        model.addAttribute("mesage",reviewService.saveReview(reviewDto));
        return "frontend/products";
    }
    @RequestMapping("/products")
    public String products(){
        return "frontend/product";
    }
    @RequestMapping("/blog")
    public String blog(){
        return "frontend/blog";
    }
    @RequestMapping("/contact")
    public String contact(){
        return "frontend/contact";
    }

    @RequestMapping("product/detail")
    public String productDetail(){
        return "frontend/product_detail";
    }

}

