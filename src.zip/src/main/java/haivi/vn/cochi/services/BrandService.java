package haivi.vn.cochi.services;

import haivi.vn.cochi.dto.BrandDto;
import haivi.vn.cochi.dto.RepositoryDto;
import haivi.vn.cochi.entities.BrandEntity;
import haivi.vn.cochi.repository.BrandEntityRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;


import java.util.List;


@Service
public class BrandService {
    @Autowired
    BrandEntityRepository brandEntityRepository;

    public BrandDto detailById(Long id){
        BrandEntity brandEntity= brandEntityRepository.findById(id).get();
        BrandDto brandDto= new BrandDto();
        if(brandEntity!=null)
            BeanUtils.copyProperties(brandEntity,brandDto);
        return brandDto;
    }


    public RepositoryDto update(BrandDto brandDto){
        if(brandDto==null||brandDto.getId()==null)
            return new RepositoryDto(1,"b.brand.update.fail");
        BrandEntity brandEntity= brandEntityRepository.findById(brandDto.getId()).get();
        if(brandEntity==null)
            return new RepositoryDto(1,"b.brand.update.fail");
        brandEntity.setNameEn(brandDto.getNameEn());
        brandEntity.setNameVi(brandDto.getNameVi());
        brandEntityRepository.save(brandEntity);
        return new RepositoryDto(1,"b.brand.update.success");
    }
    public RepositoryDto save(BrandDto brandDto){
        if(brandDto==null)
            return new RepositoryDto(1,"b.brand.create.fail");
        if(brandDto.getId() !=null)
            return update(brandDto);
        brandEntityRepository.save(brandDto.converToEntity());
        return new RepositoryDto(1,"b.brand.create.success");
    }
    public void list(Integer page, Integer perpage, String seachKey, Model model){
        Page<BrandEntity> pages = brandEntityRepository.findAll(PageRequest.of(page - 1, perpage));
        model.addAttribute("page",page);
        model.addAttribute("perpage",perpage);
        model.addAttribute("total",pages.getTotalPages());
        model.addAttribute("brandList",pages.getContent());
    }
    public List<BrandEntity> findAll(){
        return brandEntityRepository.findAll();
    }
    public RepositoryDto delete(BrandDto brandDto){
        if(brandDto.getId()==null)
            return new RepositoryDto(1,"b.brand.delete.fail");
        brandEntityRepository.deleteById(brandDto.getId());
        return new RepositoryDto(1,"b.brand.delete.success");
    }
}
