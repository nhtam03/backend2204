package haivi.vn.cochi.services;

import haivi.vn.cochi.dto.OrdersDto;
import haivi.vn.cochi.dto.RepositoryDto;
import haivi.vn.cochi.entities.OrdersEntity;
import haivi.vn.cochi.entities.ProductCartEntity;
import haivi.vn.cochi.repository.OrdersEntityRepository;
import haivi.vn.cochi.repository.ProductCartEntityRepository;
import haivi.vn.cochi.repository.ProductEntityRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

@Service
public class OrdersService {
    @Autowired
    OrdersEntityRepository ordersEntityRepository;
    @Autowired
    ProductCartEntityRepository productCartEntityRepository;


    public void list(Integer page, Integer perpage, String seachKey, Model model) {
        Page<OrdersEntity> pages = ordersEntityRepository.findAll(PageRequest.of(page - 1, perpage));
        model.addAttribute("page", page);
        model.addAttribute("perpage", perpage);
        model.addAttribute("totalPage", pages.getTotalPages());
        model.addAttribute("ordersList", pages.getContent());
    }
    public OrdersDto detailById(Long id) {
        OrdersDto ordersDto = new OrdersDto();
        OrdersEntity ordersEntity = ordersEntityRepository.findById(id).get();
        if(ordersEntity !=null)
            BeanUtils.copyProperties(ordersEntity, ordersDto);
        if(!CollectionUtils.isEmpty(ordersEntity.getCarts())){
            List<ProductCartEntity> listCart= new ArrayList<>();
            for (ProductCartEntity productCartEntity : ordersEntity.getCarts()
                 ) {
                listCart.add(productCartEntity);
            }
            ordersDto.setCarts(listCart);
        }

        return ordersDto;
    }

    public RepositoryDto update(OrdersDto ordersDto) {
        if (ordersDto == null || ordersDto.getId() == null)
            return new RepositoryDto((long) 1, "order.fail.update");
        OrdersEntity ordersEntity = ordersEntityRepository.findById(ordersDto.getId()).get();
        if (ordersEntity == null)
            return new RepositoryDto((long) 1, "order.fail.update");
        ordersEntity.setCheckout(ordersDto.getCheckout());
        ordersEntity.setCheckPayment(ordersDto.getCheckPayment());
        ordersEntityRepository.save(ordersEntity);
        return new RepositoryDto((long) 2, "order.success.update");
    }
    public RepositoryDto delete(OrdersDto ordersDto) {
        if (ordersDto == null)
            return new RepositoryDto((long) 1, "order.fail.delete");
        List<ProductCartEntity> carts = productCartEntityRepository.findAllCartByOrder(ordersDto.getId());
        if(carts.size()>0) {
            for (ProductCartEntity productCartEntity : carts
            ) {
                productCartEntityRepository.delete(productCartEntity);
            }
        }
        ordersEntityRepository.deleteById(ordersDto.getId());
        return new RepositoryDto((long) 2, "brand.success.delete");
    }
}
