package haivi.vn.cochi.services;

import haivi.vn.cochi.dto.RepositoryDto;
import haivi.vn.cochi.dto.ReviewDto;
import haivi.vn.cochi.entities.ReviewEntity;
import haivi.vn.cochi.repository.ReviewEntityRepository;
import haivi.vn.cochi.repository.user.UserEntityRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class ReviewService {
    @Autowired
    ReviewEntityRepository reviewEntityRepository;
    @Autowired
    UserEntityRepository userEntityRepository;

    public ReviewDto detailById(Long id){
        ReviewEntity reviewEntity= reviewEntityRepository.findById(id).get();
        ReviewDto reviewDto= new ReviewDto();
        if(reviewEntity!=null)
            BeanUtils.copyProperties(reviewEntity,reviewDto);
        return reviewDto;
    }
    public List<ReviewDto> reviewDtoList(Long id){
        List<ReviewDto> reviews= new ArrayList<>();
        List<ReviewEntity> reviewEntityList= reviewEntityRepository.findAllProductId(id);
        if(reviewEntityList.size()>0){
            for (ReviewEntity reviewEntity: reviewEntityList
                 ) {
                ReviewDto reviewDto= new ReviewDto();
                BeanUtils.copyProperties(reviewEntity,reviewDto);
                reviewDto.setFullName(userEntityRepository.findFullName(reviewDto.getUserId()));
                reviews.add(reviewDto);
            }
        }
        return reviews;
    }
    public RepositoryDto saveReview(ReviewDto reviewDto){
        if(reviewDto ==null)
            return new RepositoryDto(1,"f.review.fail");
        if(reviewDto.getId() !=null)
            return updateReview(reviewDto);
        ReviewEntity reviewEntity =new ReviewEntity();
        BeanUtils.copyProperties(reviewDto,reviewEntity);
        reviewEntity.setStatus(0);
        reviewEntity.setDate(LocalDate.now().toString());
        reviewEntityRepository.save(reviewEntity);
        return new RepositoryDto(2,"f.review.success");
    }
    public RepositoryDto updateReview(ReviewDto reviewDto) {
        if (reviewDto == null || reviewDto.getId() == null)
            return new RepositoryDto((long) 1, "f.review.fail");
        ReviewEntity reviewEntity = reviewEntityRepository.findById(reviewDto.getId()).get();
        if (reviewEntity == null)
            return new RepositoryDto((long) 1, "f.review.fail");
        reviewEntity.setStatus(1);
        reviewEntityRepository.save(reviewEntity);
        return new RepositoryDto((long) 2, "f.review.success");
    }
    public RepositoryDto deleteReview(ReviewDto reviewDto) {
        if (reviewDto == null)
            return new RepositoryDto((long) 1, "f.review.fail");
        reviewEntityRepository.deleteById(reviewDto.getId());
        return new RepositoryDto((long) 2, "f.review.success");
    }
    public void list(Integer page, Integer perpage, String seachKey, Model model) {
        Page<ReviewEntity> pages = reviewEntityRepository.findAll(PageRequest.of(page - 1, perpage));
        model.addAttribute("page", page);
        model.addAttribute("perpage", perpage);
        model.addAttribute("totalPage", pages.getTotalPages());
        model.addAttribute("reviewsList", pages.getContent());
    }
}
