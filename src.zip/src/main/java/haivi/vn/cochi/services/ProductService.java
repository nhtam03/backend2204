package haivi.vn.cochi.services;

import haivi.vn.cochi.config.language.MessageConfig;
import haivi.vn.cochi.dto.ProductCartDto;
import haivi.vn.cochi.dto.ProductDto;
import haivi.vn.cochi.dto.RepositoryDto;
import haivi.vn.cochi.entities.OrdersEntity;
import haivi.vn.cochi.entities.ProductCartEntity;
import haivi.vn.cochi.entities.ProductEntity;
import haivi.vn.cochi.entities.user.UserEntity;
import haivi.vn.cochi.repository.*;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import java.text.Normalizer;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

@Service
@Transactional
public class ProductService {
    @Autowired
    MessageConfig messageConfig;
    @Autowired
    ProductEntityRepository productEntityRepository;
    @Autowired
    BrandEntityRepository brandEntityRepository;
    @Autowired
    CategoryEntityRepository categoryEntityRepository;
    @Autowired
    ProductCartEntityRepository productCartEntityRepository;
    @Autowired
    OrdersEntityRepository ordersEntityRepository;


    public RepositoryDto update(ProductDto productDto) {
        if (productDto == null || productDto.getId() == null)
            return new RepositoryDto(1, messageConfig.getMessage("b.product.update.fail"));
        ProductEntity productEntity = productEntityRepository.findById(productDto.getId()).get();
        if (productEntity == null)
            return new RepositoryDto(1, messageConfig.getMessage("b.product.update.fail"));
        productEntity.setNameEn(productDto.getNameEn());
        productEntity.setNameVi(productDto.getNameVi());
        productEntity.setPacking(productDto.getPacking());
        productEntity.setElementEn(productDto.getElementEn());
        productEntity.setElementVi(productDto.getElementVi());
        productEntity.setUserManualEn(productDto.getUserManualEn());
        productEntity.setUserManualVi(productDto.getUserManualVi());
        productEntity.setExpiry(productDto.getExpiry());
        productEntity.setDescriptionEn(productDto.getDescriptionEn());
        productEntity.setDescriptionVi(productDto.getDescriptionVi());
        productEntity.setCategoryId(productDto.getCategoryId());
        productEntity.setBrandId(productDto.getBrandId());
        productEntity.setPrice(productDto.getPrice());
        productEntity.setStatus(productDto.getStatus());
        productEntity.setImage(productDto.getImage());
        productEntity.setImage1(productDto.getImage1());
        productEntity.setImage2(productDto.getImage2());
        productEntity.setImage3(productDto.getImage3());
        productEntity.setImage4(productDto.getImage4());
        productEntity.setCodeEn(converToCode(productDto.getNameEn()));
        //productEntity.setCodeVi(converToCode(productDto.getCodeVi()));
        productEntityRepository.save(productEntity);
        return new RepositoryDto(1, messageConfig.getMessage("b.product.update.success"));
    }

    public RepositoryDto save(ProductDto productDto) {
        if (productDto.getId() != null)
            return update(productDto);
        ProductEntity productEntity = new ProductEntity();
        productEntity.setCodeEn(converToCode(productDto.getNameEn()));
       // productEntity.setCodeVi(converToCode(productDto.getCodeVi()));
        productEntityRepository.save(productDto.convertToEntity());
        return new RepositoryDto(1, messageConfig.getMessage("b.product.create.success"));
    }

    public void List(Integer page, Integer perpage, String seachKey, Model model) {
        Page<ProductEntity> products = productEntityRepository.findAll(PageRequest.of(page - 1, perpage));
        model.addAttribute("page", page);
        model.addAttribute("perpage", perpage);
        model.addAttribute("total", products.getTotalPages());
        model.addAttribute("products", products.getContent());
    }

    public ProductDto detailById(Long id) {
        ProductEntity productEntity = productEntityRepository.findById(id).get();
        ProductDto productDto = new ProductDto();
        if (productEntity != null)
            BeanUtils.copyProperties(productEntity, productDto);
        return productDto;
    }

    public ProductDto detailByCodeEn(String codeEn) {
        ProductEntity productEntity = productEntityRepository.findProductByCodeEn(codeEn);
        ProductDto productDto = new ProductDto();
        if (productEntity != null)
            BeanUtils.copyProperties(productEntity, productDto);
        return productDto;
    }

    public RepositoryDto delete(Long id) {
        ProductEntity productEntity = productEntityRepository.findById(id).get();
        if (productEntity == null)
            return new RepositoryDto((long) 1, "b.product.delete.fail");
        productEntityRepository.delete(productEntity);
        return new RepositoryDto((long) 2, "b.product.delete.success");
    }
    public  String converToCode(String name){
        String code= null;
        name=name.trim().toLowerCase();
        String temp = Normalizer.normalize(name, Normalizer.Form.NFD);
        Pattern pattern = Pattern.compile("\\p{InCombiningDiacriticalMarks}+");
        code= pattern.matcher(temp).replaceAll("");
        code=code.replaceAll(" ","-");
        return code;
    }
    public List<ProductDto> findAll(){
        List<ProductEntity> productEntities= productEntityRepository.findAll();
        List<ProductDto> products= new ArrayList<>();
        if(productEntities.size()>0)
       for (ProductEntity productEntity:productEntities  ){
           ProductDto productDto= new ProductDto();
           BeanUtils.copyProperties(productEntity,productDto);
           products.add(productDto);
       }
        return products;
    }

    public List<ProductDto> findAllByCategory(Long id){
        List<ProductEntity> productEntities= productEntityRepository.findAllCategoryId(id);
        List<ProductDto> productDtos= new ArrayList<>();
        if(productEntities.size()>0)
            for (ProductEntity productEntity:productEntities  ){
                ProductDto productDto= new ProductDto();
                BeanUtils.copyProperties(productEntity,productDto);
                productDtos.add(productDto);
            }
        return productDtos;
    }
    public List<ProductDto> findAllTop6Sale(){
        List<ProductEntity> productEntities= productEntityRepository.findAllTop6Sale();
        List<ProductDto> productDtos= new ArrayList<>();
        if(productEntities.size()>0)
            for (ProductEntity productEntity:productEntities  ){
                ProductDto productDto= new ProductDto();
                BeanUtils.copyProperties(productEntity,productDto);
                productDtos.add(productDto);
            }
        return productDtos;
    }
    public List<ProductDto> findAllTop6Review(){
        List<ProductEntity> productEntities= productEntityRepository.findAllTop6Review();
        List<ProductDto> productDtos= new ArrayList<>();
        if(productEntities.size()>0)
            for (ProductEntity productEntity:productEntities  ){
                ProductDto productDto= new ProductDto();
                BeanUtils.copyProperties(productEntity,productDto);
                productDtos.add(productDto);
            }
        return productDtos;
    }


    public void findAllSortSale( Model model){
        List<ProductEntity> products=productEntityRepository.findAllSortSale();
        model.addAttribute("productDtos",products);
    }

    public void findAllSortReview( Model model){
        List<ProductEntity> products=productEntityRepository.findAllSortReview();
        model.addAttribute("productDtos",products);
    }


    public List<ProductCartEntity> getListCart() {
        Long userId = ((UserEntity) SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getId();
        List<ProductCartEntity> carts=productCartEntityRepository.findAllCart(userId);
        return carts;
    }
    public void cart(ProductCartDto productCartDto) {
        Long userId = ((UserEntity)SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getId();
        ProductCartEntity productCartEntity = productCartEntityRepository.findFirstByProductIdAndUserId(productCartDto.getProductId(), userId);
        if (productCartEntity != null && productCartEntity.getStatus()==0) productCartEntity.setNumber(productCartDto.getNumber());
        else {
            productCartEntity = new ProductCartEntity();
            productCartEntity.setUserId(userId);
            productCartEntity.setProductId(productCartDto.getProductId());
            productCartEntity.setNumber(productCartDto.getNumber());
            productCartEntity.setStatus(productCartDto.getStatus());
        }
        productCartEntityRepository.save(productCartEntity);
    }
    public void checkout(){
        OrdersEntity ordersEntity = new OrdersEntity();
        Long userId = ((UserEntity)SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getId();
        List<ProductCartEntity> carts=productCartEntityRepository.findAllCart(userId);
        if(carts!=null){
            Double total=0.0;
            String number=userId.toString() + LocalDate.now().toString();
            ordersEntity.setUserId(userId);
            ordersEntity.setNumber(number);
            ordersEntity.setCheckout(0);
            ordersEntity.setCheckPayment(0);
            ordersEntity.setDay(LocalDate.now().toString());
            for (ProductCartEntity cart:carts
                 ) {
            total+=cart.getProductEntity().getPrice();
            }
            ordersEntity.setTotal(total*1.1);
            ordersEntity.setCarts(carts);
        }
        ordersEntityRepository.save(ordersEntity);
        // update cart
        if(ordersEntity.getId() !=null){
            for (ProductCartEntity cart:carts
            ) {
                cart.setStatus(1);
                cart.setOrderId(ordersEntity.getId());
                productCartEntityRepository.save(cart);
            }
        }


    }

}