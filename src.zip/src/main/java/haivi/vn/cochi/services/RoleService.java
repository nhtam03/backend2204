package haivi.vn.cochi.services;

import haivi.vn.cochi.dto.RepositoryDto;
import haivi.vn.cochi.dto.user.RoleDto;
import haivi.vn.cochi.entities.user.RoleEntity;
import haivi.vn.cochi.repository.RoleEntityRepository;
import haivi.vn.cochi.repository.user.UserRoleEntityRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import java.util.List;

@Service
public class RoleService {
    @Autowired
    RoleEntityRepository roleEntityRepository;
    @Autowired
    UserRoleEntityRepository userRoleEntityRepository;

    public  void list(Integer page, Integer perpage, String seachKey, Model model){
        Page<RoleEntity> roles=roleEntityRepository.findAll(PageRequest.of(page-1,perpage));
        model.addAttribute("page",page);
        model.addAttribute("perpage",perpage);
        model.addAttribute("total",roles.getTotalPages());
        model.addAttribute("roleList",roles.getContent());
    }
    public RoleDto findById(Long id){
        RoleEntity roleEntity= roleEntityRepository.findById(id).get();
        RoleDto roleDto= new RoleDto();
        if(roleEntity!=null)
            BeanUtils.copyProperties(roleEntity,roleDto);
        return roleDto;
    }
    public List<RoleEntity> findAll(){
       return roleEntityRepository.findAll();
    }
    // Lưu vào CSDL
    public RepositoryDto save( RoleDto roleDto){
        if(roleDto==null)
            return new RepositoryDto(2,"b.role.create.fail");
        if(roleDto.getId()!=null)
            return update(roleDto);
        roleEntityRepository.save(roleDto.convertToEntity());
        return new RepositoryDto(2,"b.role.create.success");
    }
    // Cập nhật vào CSDL
    public  RepositoryDto update(RoleDto roleDto){
        if(roleDto==null||roleDto.getId()==null)
            return new RepositoryDto(2,"b.role.update.fail");
        RoleEntity roleEntity= roleEntityRepository.findById(roleDto.getId()).get();
        if(roleEntity==null)
            return new RepositoryDto(2,"b.role.create.fail");
        roleEntity.setDescriptionEn(roleDto.getDescriptionEn());
        roleEntity.setDescriptionVi(roleDto.getDescriptionVi());
        roleEntityRepository.save(roleEntity);
        return new RepositoryDto(2,"b.role.update.success");
    }
  // Delete
    public RepositoryDto delete(Long id){
        RoleEntity roleEntity= roleEntityRepository.findById(id).get();
        if(roleEntity==null)
            return new RepositoryDto(2,"b.role.delete.fail");
        userRoleEntityRepository.deleteAllByRoleId(roleEntity.getId());
        roleEntityRepository.delete(roleEntity);
        return new RepositoryDto(2,"b.role.delete.success");
    }
}
