package haivi.vn.cochi.services;

import haivi.vn.cochi.config.language.MessageConfig;
import haivi.vn.cochi.dto.EmailDetailDto;
import haivi.vn.cochi.dto.RepositoryDto;
import haivi.vn.cochi.dto.user.UserDto;
import haivi.vn.cochi.entities.user.RoleEntity;
import haivi.vn.cochi.entities.user.UserEntity;
import haivi.vn.cochi.entities.user.UserRoleEntity;
import haivi.vn.cochi.entities.user.UserTokenEntity;
import haivi.vn.cochi.repository.RoleEntityRepository;
import haivi.vn.cochi.repository.user.UserEntityRepository;
import haivi.vn.cochi.repository.user.UserRoleEntityRepository;
import haivi.vn.cochi.repository.user.UserTokenEntityRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;

import javax.transaction.Transactional;
import java.util.UUID;

@Transactional
@Service
public class UserService {

    @Autowired
    UserEntityRepository userEntityRepository;
    @Autowired
    MessageConfig messageConfig;
    @Autowired
    PasswordEncoder passwordEncoder;
    @Autowired
    UserRoleEntityRepository userRoleEntityRepository;
    @Autowired
    RoleEntityRepository roleEntityRepository;
    @Autowired
    UserTokenEntityRepository userTokenEntityRepository;
    @Autowired
    EmailServiceImpl emailService;


    public RepositoryDto signin (UserDto userDto){
        // Lưu vào bảng USER

        userDto.setStatus(0);
        RepositoryDto repositoryDto=save(userDto);
        // Lưu vào bảng USER_ROLE với role là CUSTOMMER
        UserRoleEntity userRoleEntity= new UserRoleEntity();
        userRoleEntity.setUserId(userDto.getId());
        userRoleEntity.setRoleId((long)4);
        userRoleEntityRepository.save(userRoleEntity);
        // Lưu vào bản USER_TOKEN
        UserTokenEntity userTokenEntity=new UserTokenEntity();
        userTokenEntity.setUserId(userDto.getId());
        userTokenEntity.setToken(UUID.randomUUID().toString());
        userTokenEntityRepository.save(userTokenEntity);
        //Gởi mail
        EmailDetailDto emailDetailDto= new EmailDetailDto();
        emailDetailDto.setRecipient(userDto.getEmail());// Người nhận
        emailDetailDto.setMsgBody("Vui lòng click vào đây để kích hoạt tài khoản: http://localhost:8080/active-account/"+userTokenEntity.getToken());
        emailDetailDto.setSubject("Xác nhận tài khoản");
        emailDetailDto.setAttachment("");
        emailService.sendSimpleMail(emailDetailDto);
        return  repositoryDto;
    }

    public String verifyToken (String token){
        String msg="";
        UserTokenEntity userTokenEntity = userTokenEntityRepository.findFirstByToken(token);
        if(userTokenEntity==null) return msg="Token không đúng";
        UserEntity userEntity= userEntityRepository.findById(userTokenEntity.getUserId()).get();
        if(userEntity==null) return msg="Tài khoản không tồn tại";
        if(userEntity.getStatus()==1) return "Tài khoản đã được kích hoạt";
        userEntity.setStatus(1);
        userEntityRepository.save(userEntity);
        msg="Kích hoạt tài khoản thành công";
        userTokenEntityRepository.deleteAllByUserId(userEntity.getId());
        return  msg;
    }




    public RepositoryDto save(UserDto userDto){
        if(userDto==null)
            return new RepositoryDto(1,messageConfig.getMessage("b.user.create.fail"));
        if(userDto.getId()!=null)
            return update(userDto);
        UserEntity userEntity = userEntityRepository.findFirstByEmail(userDto.getEmail());
        if(userEntityRepository.existsByEmail(userDto.getEmail()))
            return new RepositoryDto((long)1,messageConfig.getMessage("b.user.create.fail"));
        UserEntity userEntitySave= userDto.convertToEntity();
        userEntitySave.setPassWord(passwordEncoder.encode(userDto.getPassWord()));
        userEntityRepository.save(userEntitySave);
        // Lấy thông tin user đã lưu, lưu vào bảng user_role
        if(!CollectionUtils.isEmpty(userDto.getRoles())){
            for( RoleEntity role: userDto.getRoles()){
                UserRoleEntity userRoleEntity= new UserRoleEntity();
                userRoleEntity.setRoleId(role.getId());
                userRoleEntity.setUserId(userEntitySave.getId());
                userRoleEntityRepository.save(userRoleEntity);
            }
        }
        userDto.setId(userEntitySave.getId());
        return new RepositoryDto(1,messageConfig.getMessage("b.user.create.success"));
    }
// Update
    public RepositoryDto update(UserDto userDto){
        if(userDto==null || userDto.getId()==null)
            return new RepositoryDto(1,messageConfig.getMessage("b.user.update.fail"));
        // Luu vao bang User
        UserEntity userEntity= userEntityRepository.findById(userDto.getId()).get();
        if(userEntity==null)
            return new RepositoryDto(1,messageConfig.getMessage("b.user.fail.success"));
        userEntity.setFullName(userDto.getFullName());
        userEntity.setStatus(userDto.getStatus());
        userEntityRepository.save(userEntity);
        // Xoa role cu
        userRoleEntityRepository.deleteAllByUserId(userDto.getId());
        if(!CollectionUtils.isEmpty(userDto.getRoles())){
            for(RoleEntity role: userDto.getRoles()){
                UserRoleEntity userRoleEntity= new UserRoleEntity();
                userRoleEntity.setRoleId(role.getId());
                userRoleEntity.setUserId(userEntity.getId());
                userRoleEntityRepository.save(userRoleEntity);
            }
        }
        return new RepositoryDto(1,messageConfig.getMessage("b.user.update.success"));

    }
    public void list(Integer page, Integer perpage, String seachKey, Model model){
        Page<UserEntity> pages =userEntityRepository.findAll(PageRequest.of(page-1,perpage));
        model.addAttribute("list",pages.getContent());
        model.addAttribute("page",page);
        model.addAttribute("perpage",perpage);
        model.addAttribute("total",pages.getTotalPages());
    }

    public UserDto detailById(Long id){
        UserEntity userEntity= userEntityRepository.findById(id).get();
        UserDto userDto= new UserDto();
        if(userEntity !=null)
            BeanUtils.copyProperties(userEntity,userDto);
        if(!CollectionUtils.isEmpty(userEntity.getRoles()))
userEntity.getRoles().forEach(roleEntity -> {
    userDto.getRoles().add(roleEntity);
});
        return userDto;
    }
}
