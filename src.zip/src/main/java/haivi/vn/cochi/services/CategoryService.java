package haivi.vn.cochi.services;

import haivi.vn.cochi.dto.CategoryDto;
import haivi.vn.cochi.dto.RepositoryDto;
import haivi.vn.cochi.entities.BrandEntity;
import haivi.vn.cochi.entities.CategoryEntity;
import haivi.vn.cochi.repository.CategoryEntityRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import java.util.List;

@Service
public class CategoryService {
    @Autowired
    CategoryEntityRepository categoryEntityRepository;

    public void list(Integer page, Integer perpage, String seachKey, Model model){
        Page<CategoryEntity> pages= categoryEntityRepository.findAll(PageRequest.of(page-1,perpage));
        model.addAttribute("page",page);
        model.addAttribute("perpage",perpage);
        model.addAttribute("total",pages.getTotalPages());
        model.addAttribute("categoryList",pages.getContent());
    }
    public RepositoryDto update(CategoryDto categoryDto){
        if(categoryDto==null||categoryDto.getId()==null)
            return new RepositoryDto(1,"b.category.update.fail");
        CategoryEntity categoryEntity = categoryEntityRepository.findById(categoryDto.getId()).get();
        if(categoryEntity==null)
            return new RepositoryDto(1,"b.category.update.fail");
        categoryEntity.setNameEn(categoryDto.getNameEn());
        categoryEntity.setNameVi(categoryDto.getNameVi());
        categoryEntityRepository.save(categoryEntity);
        return new RepositoryDto(1,"b.category.update.success");
    }
    public RepositoryDto save(CategoryDto categoryDto){
        if(categoryDto==null)
        return new RepositoryDto(1,"b.category.create.fail");
        if (categoryDto.getId()!=null)
            return update(categoryDto);
        categoryEntityRepository.save(categoryDto.convertoEntity());
        return new RepositoryDto(1,"b.category.create.success");
    }
    public CategoryDto detailById(Long id){
        CategoryEntity categoryEntity= categoryEntityRepository.findById(id).get();
        CategoryDto categoryDto= new CategoryDto();
        if(categoryEntity!=null)
            BeanUtils.copyProperties(categoryEntity,categoryDto);
        return categoryDto;
    }

    public List<CategoryEntity> findAll(){
        return categoryEntityRepository.findAll();
    }
    public RepositoryDto delete(CategoryDto categoryDto){
        if(categoryDto.getId()==null)
            return new RepositoryDto(1,"b.category.delete.fail");
        categoryEntityRepository.deleteById(categoryDto.getId());
        return new RepositoryDto(1,"b.category.delete.success");
    }

}
