package haivi.vn.cochi.config;

import haivi.vn.cochi.config.services.LoginSuccessHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfiguration {
    @Autowired
    UserDetailsService userDetailsService;
    @Autowired
    LoginSuccessHandler loginSuccessHandler;

    // Ma hoa password
    @Bean
    PasswordEncoder passwordEncoder(){
        return new BCryptPasswordEncoder();
    }
    // Đăng ký đường dẫn Authorization
    // Đăng ký trang và form login
    // Đăng ký các thông số của trang login khi supmit lên cái gì
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception{
        http.authorizeRequests()
                .antMatchers("/backend/**").authenticated()
                .anyRequest().permitAll();
        http.formLogin()
                .loginPage("/login")
                .usernameParameter("username")
                .passwordParameter("password")
                .loginProcessingUrl("/doLogin")
                .failureUrl("/login?error=true")
                .successHandler(loginSuccessHandler);
                //.defaultSuccessUrl("/backend/role/list");
        http.logout().logoutUrl("/logout");
        http.rememberMe()
                .rememberMeParameter("remember")
                .key("remember Me Encryption Key")
                .rememberMeCookieName("rememberMeCookieName")
                .tokenValiditySeconds(3*24*60*60);

        http.headers().frameOptions().sameOrigin();
        http.csrf().disable();
        return http.build();
    }
    // ignor: đường dẫn ngoại lệ
    @Bean
    public WebSecurityCustomizer webSecurityCustomizer(){
        return (web) -> web.ignoring().antMatchers("/image/**","/css/**","/js/**");
    }

}
