package haivi.vn.cochi.config.services;

import haivi.vn.cochi.entities.user.UserEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;
import org.springframework.stereotype.Component;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Iterator;

@Component
public class LoginSuccessHandler extends SavedRequestAwareAuthenticationSuccessHandler {

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
                                        Authentication authentication) throws IOException, ServletException {

        UserEntity principal = (UserEntity) authentication.getPrincipal();
        System.out.println("principal" + principal.getUsername());
        boolean isAdmin = false;
        boolean isUser = false;
        boolean isEditor=false;
        boolean isCreater=false;
        Iterator<GrantedAuthority> grantedAuthorityIterator = (Iterator<GrantedAuthority>) principal.getAuthorities().iterator();
        while (grantedAuthorityIterator.hasNext()) {
            GrantedAuthority authority = grantedAuthorityIterator.next();
            if (authority.getAuthority().equalsIgnoreCase("ROLE_ADMIN")) {
                isAdmin = true;
            }
            if (authority.getAuthority().equalsIgnoreCase("ROLE_EDITOR")) {
                isEditor = true;
            }
            if (authority.getAuthority().equalsIgnoreCase("ROLE_CREATER")) {
                isCreater = true;
            }
            if (authority.getAuthority().equalsIgnoreCase("CUSTOMER")) {
                isUser = true;
            }
        }
        if (isAdmin || isEditor) {
            response.sendRedirect("/backend/user/list");
        } else if (isCreater){
            response.sendRedirect("/backend/product/list");
        } else {
            response.sendRedirect("/");
        }
    }
}
