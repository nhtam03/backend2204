package haivi.vn.cochi.entities;

import lombok.Data;

import javax.persistence.*;
@Entity
@Table(name = "CATEGORY",schema = "haivi",catalog = "")
@Data
public class CategoryEntity extends EntityBase {
    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Basic
    @Column(name = "NAME_EN")
    private String nameEn;
    @Basic
    @Column(name = "NAME_VI")
    private String nameVi;

}
