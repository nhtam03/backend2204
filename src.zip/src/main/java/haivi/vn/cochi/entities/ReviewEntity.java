package haivi.vn.cochi.entities;

import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "REVIEW",catalog = "",schema = "haivi")
@Data
public class ReviewEntity  extends EntityBase{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private  Long id;
    @Basic
    @Column(name = "USER_ID")
    private Long userId;
    @Basic
    @Column(name = "PRODUCT_ID")
    private Long productId;
    @Basic
    @Column(name = "MARK")
    private Integer mark;
    @Basic
    @Column(name = "CONTENT")
    private String content;
    @Basic
    @Column(name = "DATE")
    private String date;
    @Basic
    @Column(name = "STATUS")
    private Integer status;

    @Transient
    public String fullName;

}
