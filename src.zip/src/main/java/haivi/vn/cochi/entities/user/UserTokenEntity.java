package haivi.vn.cochi.entities.user;

import haivi.vn.cochi.entities.EntityBase;
import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "user_token", schema = "haivi", catalog = "")
public class UserTokenEntity extends EntityBase {
    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Basic
    @Column(name = "USER_ID")
    private Long userId;
    @Basic
    @Column(name = "TOKEN")
    private String token;

}
