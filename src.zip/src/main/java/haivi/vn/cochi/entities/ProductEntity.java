package haivi.vn.cochi.entities;

import lombok.Data;

import javax.persistence.*;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "PRODUCT",schema = "haivi",catalog = "")
@Data
public class ProductEntity extends EntityBase{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;
    @Basic
    @Column(name = "CODE_EN")
    private String codeEn;
    @Basic
    @Column(name = "CODE_VI")
    private String codeVi;
    @Basic
    @Column(name = "NAME_EN")
    private String nameEn;
    @Basic
    @Column(name = "NAME_VI")
    private String nameVi;
    @Basic
    @Column(name = "PACKING")
    private String packing;
    @Basic
    @Column(name = "ELEMENT_EN")
    private String elementEn;
    @Basic
    @Column(name = "ELEMENT_VI")
    private String elementVi;
    @Basic
    @Column(name = "USER_MANUAL_EN")
    private String userManualEn;
    @Basic
    @Column(name = "USER_MANUAL_VI")
    private String userManualVi;
    @Basic
    @Column(name = "EXPIRY")
    private String expiry;
    @Basic
    @Column(name = "DESCRIPTION_EN")
    private String descriptionEn;
    @Basic
    @Column(name = "DESCRIPTION_VI")
    private String descriptionVi;
    @Basic
    @Column(name = "CATEGORY_ID")
    private Long categoryId;
    @Basic
    @Column(name = "BRAND_ID")
    private Long brandId;
    @Basic
    @Column(name = "PRICE")
    private Double price;
    @Basic
    @Column(name = "STATUS")
    private Integer status;
    @Basic
    @Column(name = "IMAGE")
    private String image;
    @Basic
    @Column(name = "IMAGE_1")
    private String image1;
    @Basic
    @Column(name = "IMAGE_2")
    private String image2;
    @Basic
    @Column(name = "IMAGE_3")
    private String image3;
    @Basic
    @Column(name = "IMAGE_4")
    private String image4;
    @OneToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
    @JoinColumn(name = "PRODUCT_ID", referencedColumnName = "ID",updatable = false,insertable = false)
    private List<ReviewEntity> reviews ;

}
