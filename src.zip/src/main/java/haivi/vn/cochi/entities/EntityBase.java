package haivi.vn.cochi.entities;

import java.io.Serializable;

public class EntityBase implements Serializable {
    public Long getId(){
        return null;
    }
}
