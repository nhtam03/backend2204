package haivi.vn.cochi.entities;

import lombok.Data;

import javax.persistence.*;



import java.time.Instant;

import java.util.Date;
import java.util.List;


@Entity
@Data
@Table(name = "ORDERS",schema = "haivi",catalog = "")
public class OrdersEntity extends EntityBase {
    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Basic
    @Column(name = "USER_ID")
    private Long userId;
    @Basic
    @Column(name = "NUMBER")
    private String number;
    @Basic
    @Column(name = "TOTAL")
    private Double total;
    @Basic
    @Column(name = "CHECKOUT")
    private Integer checkout;
    @Basic
    @Column(name = "CHECK_PAYMENT")
    private Integer checkPayment;
    @Basic
    @Column(name = "ADDRESS_SHIP")
    private String addressShip;
    @Basic
    @Column(name = "DAY")
    private String day;
    @OneToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
    @JoinColumn(name = "ORDER_ID", referencedColumnName = "ID",updatable = false,insertable = false)
    private List<ProductCartEntity> carts ;
}
