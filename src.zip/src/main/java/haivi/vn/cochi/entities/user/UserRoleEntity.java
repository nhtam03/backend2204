package haivi.vn.cochi.entities.user;

import haivi.vn.cochi.entities.EntityBase;
import lombok.Data;
import javax.persistence.*;


@Entity
@Table(name = "USER_ROLE",schema = "haivi",catalog = "")
@Data
public class UserRoleEntity  extends EntityBase {
    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Basic
    @Column(name = "USER_ID")
    private Long userId;
    @Basic
    @Column(name = "ROLE_ID")
    private Long roleId;
}
