package haivi.vn.cochi.entities.user;
import haivi.vn.cochi.entities.EntityBase;
import lombok.Data;

import javax.persistence.*;


@Entity
@Table(name = "ROLE", schema = "haivi",catalog = "")
@Data
public class RoleEntity extends EntityBase {
    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Basic
    @Column(name = "ROLE")
    private String role;
    @Basic
    @Column(name = "DESCRIPTION_VI")
    public String descriptionVi;
    @Basic
    @Column(name = "DESCRIPTION_EN")
    public String descriptionEn;
}
