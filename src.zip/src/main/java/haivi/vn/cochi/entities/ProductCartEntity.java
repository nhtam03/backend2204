package haivi.vn.cochi.entities;

import lombok.Data;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Data
@Table(name = "PRODUCT_CART",schema = "haivi",catalog = "")
public class ProductCartEntity extends EntityBase {
    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Basic
    @Column(name = "PRODUCT_ID")
    private Long productId;
    @Basic
    @Column(name = "USER_ID")
    private Long userId;
    @Basic
    @Column(name = "ORDER_ID")
    private Long orderId;
    @Basic
    @Column(name = "NUMBER")
    private Integer number;
    @Basic
    @Column(name = "STATUS")
    private Integer status;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "PRODUCT_ID", referencedColumnName = "ID", updatable = false, insertable = false)
    ProductEntity productEntity;
}
